/*****************************************************************************
 * Open MCT, Copyright (c) 2014-2024, United States Government
 * as represented by the Administrator of the National Aeronautics and Space
 * Administration. All rights reserved.
 *
 * Open MCT is licensed under the Apache License, Version 2.0 (the
 * "License"); you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 * http://www.apache.org/licenses/LICENSE-2.0.
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
 * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
 * License for the specific language governing permissions and limitations
 * under the License.
 *
 * Open MCT includes source code licensed under additional open source
 * licenses. See the Open Source Licenses file (LICENSES.md) included with
 * this source code distribution or the Licensing information page available
 * at runtime from the About dialog for additional information.
 *****************************************************************************/

import ExampleUserProvider from './ExampleUserProvider.js';
const AUTO_LOGIN_USER = 'mct-user';
const STATUS_ROLES = ['flight', 'driver'];

export default function ExampleUserPlugin(
  { autoLoginUser, statusRoles, roles } = {
    autoLoginUser: AUTO_LOGIN_USER,
    statusRoles: STATUS_ROLES,
    roles: ['observer']
  }
) {
  return function install(openmct) {
    const userProvider = new ExampleUserProvider(openmct, {
      statusRoles,
      roles
    });

    if (autoLoginUser !== undefined) {
      userProvider.autoLogin(autoLoginUser);
    }

    openmct.user.setProvider(userProvider);
  };
}

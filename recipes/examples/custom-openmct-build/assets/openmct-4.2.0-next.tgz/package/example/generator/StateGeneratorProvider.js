/*****************************************************************************
 * Open MCT, Copyright (c) 2014-2025, United States Government
 * as represented by the Administrator of the National Aeronautics and Space
 * Administration. All rights reserved.
 *
 * Open MCT is licensed under the Apache License, Version 2.0 (the
 * "License"); you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 * http://www.apache.org/licenses/LICENSE-2.0.
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
 * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
 * License for the specific language governing permissions and limitations
 * under the License.
 *
 * Open MCT includes source code licensed under additional open source
 * licenses. See the Open Source Licenses file (LICENSES.md) included with
 * this source code distribution or the Licensing information page available
 * at runtime from the About dialog for additional information.
 *****************************************************************************/

export default class StateGeneratorProvider {
  constructor(openmct) {
    this.openmct = openmct;
  }

  supportsRequest(domainObject, options) {
    return domainObject.type === 'example.state-generator';
  }

  supportsSubscribe(domainObject) {
    return domainObject.type === 'example.state-generator';
  }

  subscribe(domainObject, callback, options) {
    const duration = domainObject.telemetry.duration * 1000;
    let tick = 0;
    const interval = setInterval(() => {
      tick += 1;
      let now = this.openmct.time.now() || Date.now();
      let flip = false;
      if (domainObject.telemetry.outOfOrder && tick % 2 === 0) {
        now -= duration * 1.5;
        flip = true;
      }
      const datum = this.#pointForTimestamp(now, duration, domainObject.name, flip);

      if (!this.#shouldBeFiltered(datum, options)) {
        datum.value = String(datum.value);
        callback(datum);
      }
    }, duration);

    return () => {
      clearInterval(interval);
    };
  }

  request(domainObject, options) {
    let start = options.start;
    const now = this.openmct.time.now() || Date.now();
    const end = Math.min(now, options.end); // no future values
    const duration = domainObject.telemetry.duration * 1000;
    if (options.strategy === 'latest' || options.size === 1) {
      start = end;
    }

    const data = [];
    while (start <= end && data.length < 5000) {
      const point = this.#pointForTimestamp(start, duration, domainObject.name);

      if (!this.#shouldBeFiltered(point, options)) {
        data.push(point);
      }
      start += duration;
    }

    return Promise.resolve(data);
  }

  #pointForTimestamp(timestamp, duration, name, flip = false) {
    const key = this.openmct.time.getTimeSystem()?.key || 'utc';
    const point = {
      name: name,
      value: Math.floor(timestamp / duration) % 2
    };
    if (flip) {
      point.value = 99;
    }
    point[key] = Math.floor(timestamp / duration) * duration;
    return point;
  }

  #shouldBeFiltered(point, options) {
    const valueToFilter = options?.filters?.state?.equals?.[0];

    if (!valueToFilter) {
      return false;
    }

    const { value } = point;

    return value !== Number(valueToFilter);
  }
}
